﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HGH.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult TermAndCondations()
        {
            return View();
        }

        public ActionResult ContactUs()
        {
            return View();
        }

        public ViewResult INdex()
        {
            return View();
        }
        public ActionResult Privacy()
        {
            return View();
        }
    }
}
