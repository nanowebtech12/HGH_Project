﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using HGH.HGHServiceReference;
using HGH.Models;


namespace HGH.Controllers
{
    public class ProductController : Controller
    {
        //
        // GET: /Product/
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Products(string cat)
        {
            ViewBag.cat = cat;
            return View();
        }

        public ActionResult ProductDetail(string cat)
        {
            ViewBag.url = cat;
            return View();
        }

        public bool UpdateSession(string shoppingCart)
        {
            var cartitems = new JavaScriptSerializer().Deserialize<List<Cart>>(shoppingCart);
            Session["CartItem"] = shoppingCart;
            return true;
        }
        public JsonResult GetShoppingCart()
        {
            if (Session["CartItem"] != null)
            {
                return Json(new { d = true, data = new JavaScriptSerializer().Deserialize(Session["CartItem"].ToString(), typeof(object)) }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { d = false, data = "" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ViewCart()
        {
            return View();
        }

        public ActionResult Search(string srchtext)
        {
            ViewBag.srchtext = srchtext;
            return View();
        }
    }
}
