﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.Mvc;
using HGH.Models;
using Facebook;
using System.Web.UI;

namespace HGH.Controllers
{
    public class AccountController : Controller
    {

        public object FacebookLogin(FacebookLoginModel model)
        {

            var code = Request.QueryString["code"].ToString();
            if (Request.QueryString["access_token"] == null)
            {
                return RedirectToAction("FacebookLogin1", "Account", new { client_id = "319418701592910", redirect_uri = "http://localhost:8043/account/FacebookLogin1", client_secret = "f4dd1ce89be949ee0213661dc4eee6c9", code = code });
            }
            if (Request.QueryString["access_token"] != null)
            {
                var token = Request.QueryString["access_token"].ToString();
            }
            return null;

        }
        public object FacebookLogin1(FacebookLoginModel model)
        {
            return null;
        }

        public ActionResult Gettoken(string code)
        {
            return RedirectToAction("FacebookLogin", "Account", new { client_id = "319418701592910", redirect_uri = "http://localhost:8043/account/FacebookLogin", client_secret = "f4dd1ce89be949ee0213661dc4eee6c9", code = code });
        }

        public ActionResult Login()
        {

            return View();
        }

        public ActionResult RetrivePassword()
        {
            return View();
        }

        public ActionResult ChangePassword()
        {
            return View();
        }
        public ActionResult Guest()
        {
            return View();
        }

        public ActionResult CreateAccount()
        {
            return View();
        }

        public ActionResult MyAccount()
        {
            return View();
        }

        public bool SetUserId(int id)
        {
            Session["UserId"] = id;
            return true;
        }
    }
}
