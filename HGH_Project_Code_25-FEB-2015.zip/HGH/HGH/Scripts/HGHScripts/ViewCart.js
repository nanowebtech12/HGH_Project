﻿$(function () {
    function CartItemsViewModel() {
        var self = this;
        //self.Items = ko.observableArray(cart.shoppingCart());
        self.RemoveItem = function (item) {
            cart.shoppingCart.remove(item);
            UpdateSession();
          //  $.post("/Product/UpdateSession", { shoppingCart: JSON.stringify(ko.toJSON(cart.shoppingCart())) }, function () { });
            //self.Items(cart.shoppingCart());
        }
        self.SubTotal = ko.computed(function () {
            var total = 0;
            for (var i = 0; i < cart.shoppingCart().length ; i++) {
                total += cart.shoppingCart()[i].TotalItemPrice();
            }
            return '$ ' + total.toFixed(2);
        });
        self.TotalItems = ko.computed(function () {
            return '$ ' + cart.shoppingCart().length;
        });
        self.IncreseQuentity = function (item) {
            //var items = $.grep(cart.shoppingCart(), function (e, i) { return e.productid == cartitem.productid });
            $.grep(cart.shoppingCart(),function (a) {
                if (a.productid == item.productid) {
                    if (a.Quentity() < 10) {
                        a.Quentity(a.Quentity() + 1);
                        a.TotalItemPrice(a.price * a.Quentity());
                        UpdateSession();
                       // $.post("/Product/UpdateSession", { shoppingCart: JSON.stringify(ko.toJSON(cart.shoppingCart())) }, function () { });
                    }
                }
            });
        }

        self.DecQuentity = function (item) {
            $.grep(cart.shoppingCart(),function (a) {
                if (a.productid == item.productid) {
                    if (a.Quentity() > 1) {
                        a.Quentity(a.Quentity() - 1);
                        a.TotalItemPrice(a.price * a.Quentity());
                        UpdateSession();
                        //$.post("/Product/UpdateSession", { shoppingCart: JSON.stringify(ko.toJSON(cart.shoppingCart())) }, function () { });
                    }
                }
            });
        }
        // self.totalItemprice = ko.computed(function () {  });
    }
    ko.applyBindings(CartItemsViewModel(), document.getElementById('cartitmes'));
});
