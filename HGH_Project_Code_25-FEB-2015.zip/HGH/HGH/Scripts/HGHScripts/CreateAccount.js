﻿
$(document).ready(function () {
    $("#paymentInfo").hide();
    $("#stateText").hide();
});

function UserInfo() {
    $("#newUser").show();
    $("#paymentInfo").css('display', 'none');
    $("#generalImg").prop('src', '/Content/images/gen_info_hover.png');
    $("#paymentImg").prop('src', '/Content/images/payment_info.png');
}

function PaymentInfo() {
    if ($("#form1").valid() == true) {
        $("#newUser").hide();
        $("#paymentInfo").show();
        $("#paymentImg").prop('src', '/Content/images/payment_info_hover.png');
        $("#generalImg").prop('src', '/Content/images/gen_info.png');
    }

}


$("#form1").validate({
    rules: {
        Uemail: {
            required: true,
            checkemail: true
        },
        Upass: {
            required: true,

        },
        uname: {
            required: true,


        },
        Ucnfrm: {
            required: true,
            equalTo: "#password"

        },
        lastname: {
            required: true,
        },
        date: {
            required: true,

        },
        month: {
            required: true,
        },
        year: {
            required: true,
        }
    },
    messages: {
        Uemail: {
            required: "Please enter Email",
            email: "Please enter a valid email"
        },
        Upass: {
            required: "Please enter password",

        },
        uname: {
            required: "Please enter First Name",

        },
        Ucnfrm: {
            required: "Please enter confirm password",
            equalTo: "Password not match"

        },
        lastname: {
            required: "Please enter Last Name",
        },
        date: {
            required: "Please select your date",
        },
        month: {
            required: "Please Select month"
        },
        year: {
            required: "Please Select year",
        }
    }
});


jQuery.validator.addMethod("checkemail", function (value, element) {
    return this.optional(element) || /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/.test(value) || /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/.test(value);
}, "Please enter your correct email");

$("#form2").validate({
    rules: {
        statetextbox: {
            required: true,
        },
        stateText: {
            required: true,
        },
        line1: {
            required: true,
        },

        city: {
            required: true,
        },
        zipcode: {
            required: true,
            rangelength: [5, 6],
            number: true
        },
        line2: {
            required: true
        },


    },
    messages: {
        statetextbox: {
            required: "Please enter state"
        },
        stateText: {
            required: "Please Select State",
        },

        line1: {
            required: "Please enter line 1",

        },
        line2: {
            required: "Please Enter Address"
        },
        city: {
            required: "Please enter city",

        },
        zipcode: {
            required: "Please enter zipcode",
            rangelength: "Please enter a valid zip code",
            number: "Please enter only numbers"
        },
    }
});

function country() {

    $("#country_val").change(function () {
        var country = $("#country_val").val();
        if (country != "United States of America") {
            $("#stateText").show();
            $("#state").hide();
        }
        else {
            $("#stateText").hide();
            $("#state").show();
        }

    });
}


function complete() {

    if ($("#form2").valid() == true) {
        var result = CreateUser();
        if (apiresult.tblsuccess[0].success == 'true') {
            var cid = result.tblResult[0].customerid;
            $.ajax({
                url: '/account/SetUserId',
                type: 'POST',
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({ id: cid }),
                success: function () { },
                error: function () { }
            });
        }
    }
}


var apiresult;
function CreateUser() {
    $('.errormsg').text('');
    var send = {};
    send.request = CreateUserModel();
       $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf]8",
        url: "http://api.hgh.com/HGHMobileWebServices.svc/MyAccount_CreateNewAccount",
        data: JSON.stringify(send),
        dataType: "json",
        async: false,
        success: function (msg) {
            apiresult = JSON.parse(msg);
            if (apiresult.tblsuccess[0].success == 'true') {
                return apiresult;
            }
            else {
                $('.errormsg').text(apiresult.tblsuccess[0].errormessage);
                $('html,body').animate({ scrollTop: $('.errormsg').offset().top - 150 }, 1000);

                return false;
            }

            console.log(msg);
        },
        error: function () {
            alert('Error while processing your request!');
            window.location = '/';
            return false;
        }
    });
}

var user = {};
function CreateUserModel() {
    user.emailAddress = $('#email').val();
    user.password = $('#password').val();
    user.title = $('#title :selected').val() == 'Please Select' ? '' : $('#title :selected').val();
    user.firstname = $('#name').val();
    user.lastname = $('#lastname').val();
    user.middlename = $('#nameInfo').val();
    user.gender = $(':radio:checked').val()
    user.dob = $('#month :selected').val() + '/' + $('#date :selected').val() + '/' + $('#year :selected').val();
    user.daytimephone = $('#phone').val();
    user.billingcountry = $('#country_val :selected').val();
    user.billingaddress = $('#address1').val();
    user.billingaddress2 = $('#address2').val() + ',' + $('#address3').val();
    user.billingcity = $('#city').val();;
    user.billingstate = $('#country_val :selected').val() == 'United States of America' ? $('#state :selected').val() : $('#stateText').val();
    user.billingzip = $('#zipcode').val();
    user.billingcompanyname = $('#company_name').val();
    user.cctype = $('#cardtype :selected').val();
    user.ccnumber = $('#cardNumber').val();
    user.cccvv = $('#cvvnumber').val();
    user.ccexpiration = $('#ccmonth :selected').val() + '/' + $('#ccyear :selected').val();
    return user;
}

