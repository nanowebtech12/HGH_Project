﻿$(document).ready(function () {
   
    

});
var result;


function OpenFaceBookLoginPopup() {
    debugger;
    var url = "https://www.facebook.com/dialog/oauth?";
    url += "client_id=319418701592910";
    url += "&redirect_uri=http://localhost:8043/account/FacebookLogin&response_type=code%20token";
    window.location = url;
}

function GetAccessTocken(code) {
    var url= "https://graph.facebook.com/oauth/access_token?";
    url+="    client_id=319418701592910";
    url+="&redirect_uri=http://localhost:8043/account/FacebookLogin";
    url+=" &client_secret=f4dd1ce89be949ee0213661dc4eee6c9";
    url += "&code=" + code;
}


function ValidateAndLogin() {
    $('.errormsg').text('');
    var email = $('#email').val();
    var password = $('#pwd').val();
    if (email.trim() == '') {
        $('.errormsg').text('Please enter email address.');
        return false;
    }
    if (!IsEmail(email)) {
        $('.errormsg').text('Please enter a valid  email address.');
        return false;
    }

    if (password.trim() == '') {
        $('.errormsg').text('Please enter password.');
        return false;
    }
   
    result = login(email, password);
    var resultjson = JSON.parse(result);
    if (resultjson.tblresult[0].responsecode == 0) {
        $('.errormsg').text(resultjson.tblresult[0].responsemessage);
        $('#pwd').text('');
    }
    if (resultjson.tblresult[0].responsecode == 1) {
        User.Userid = resultjson.tblresult[0].customerid;
    }
}


function login(email, password) {
    var request = {};
    request.username = email;
    request.password = password;
    var send = {};
    send.request = request;
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf]8",
        url: "http://api.hgh.com/HGHMobileWebServices.svc/MyAccount_Login",
        data: JSON.stringify(send), dataType: "json", async: false, success: function (msg) {
            result = msg;
        }, error: function () {
            alert('Error while process your request.');
        }
    });
    return result;
}