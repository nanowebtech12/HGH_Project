﻿
$(function () {
    function shoppingcartViewModel() {
        var self = this;
        self.Products = ko.observableArray();
        self.products = GetData();
        self.Products(self.products);
        self.addToCart = function (item) {
            AddItemToCart(item);
            UpdateSession();
            $('html,body').animate({ scrollTop: $('#shopingCart').offset().top - 150 }, 1000); 

        }
        self.FilterAZ = function () {
            self.products.sort(function (a, b) {
                var nameA = a.productname.toLowerCase();
                var nameB = b.productname.toLowerCase();
                if (nameA < nameB)
                    return -1
                if (nameA > nameB)
                    return 1
                return 0
            });
            self.Products(self.products);
        }

        self.FilterZA = function () {
            self.products.sort(function (a, b) {
                var nameA = a.productname.toLowerCase();
                var nameB = b.productname.toLowerCase();
                if (nameA < nameB)
                    return 1
                if (nameA > nameB)
                    return -1
                return 0
            });
            self.Products(self.products);
        }
        self.FiterPriceLowToHigh = function () {
            self.products.sort(function (a, b) {
                var nameA = a.price;
                var nameB = b.price;
                if (nameA < nameB)
                    return -1
                if (nameA > nameB)
                    return 1
                return 0
            });
            self.Products(self.products);
        }

        self.FilterPriceHighToLow = function () {
            self.products.sort(function (a, b) {
                var nameA = a.price;
                var nameB = b.price;
                if (nameA < nameB)
                    return 1
                if (nameA > nameB)
                    return -1
                return 0
            });
            self.Products(self.products);
        }

        self.FilterNewestProducts = function () {
            self.products.sort(function (a, b) {
                var nameA = a.productid;
                var nameB = b.productid;
                if (nameA < nameB)
                    return 1
                if (nameA > nameB)
                    return -1
                return 0
            });
            self.Products(self.products);
        }
    }
    ko.applyBindings(shoppingcartViewModel(), document.getElementById('products'));
    function GetData() {
        var request = {};
        request.category = cat.replace('&amp;', '&');
        var send = {};
        send.request = request;
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf]8",
            url: "http://api.hgh.com/HGHMobileWebServices.svc/Product_GetByCategory",
            data: JSON.stringify(send),
            dataType: "json",
           
            success: function (msg) {
                var res = JSON.parse(msg);
                if (res.tblresult[0].responsecode == 1) {
                    data = res.tblproducts;
                    self.products = data;
                    self.Products(self.products);
                }
                else {
                    alert(res.tblresult[0].responsemessage);
                    return false;
                }
            },
            error: function () {
            }
        });
        return data;
    };
});
var data;
var cat = '@ViewBag.cat';



