﻿var currnt = 0;
var alldata = getProductDetail();
$(function () {

    function productDetailViewModel() {
        var self = this;
        self.ccount = ko.observable(0);
        self.productsSKU = ko.observableArray(alldata.tblproductsku.sort(function (a, b) { return a.productid > b.productid; }));
        self.productName = ko.observable(alldata.tblproductname[0]);
        self.product = ko.observable(productsSKU()[currnt]);
        self.ProductDescription = ko.observableArray(alldata.tblproductdescription);
        self.Reviews = ko.observableArray(alldata.tblreviews);
        self.Ingredients = ko.observableArray(alldata.tblingredients);
        self.Ingredients_Others = ko.observableArray(alldata.tblingredients_others);
        self.Ingredients_Proprietaryblend = ko.observableArray(alldata.tblingredients_proprietaryblend);
        self.Articles = ko.observableArray(alldata.tblarticles);
        self.Newsandblogs = ko.observableArray(alldata.tblnewsandblogs);
        self.next = function () {
            if (alldata.tblproductsku.length - 1 > currnt) {
                currnt = currnt + 1;
            }
            self.product(self.productsSKU()[currnt]);
            self.ccount(currnt);
        }
        self.previous = function () {
            if (0 < currnt) {
                currnt = currnt - 1;
            }
            self.product(self.productsSKU()[currnt]);
            self.ccount(currnt);
        }
        self.price = ko.computed(function () {
            return '$ ' + self.product().price;
        });
        self.retailPrice = ko.computed(function () {
            return '$ ' + self.product().retailprice;
        });
        self.Save = ko.computed(function () {
            if (self.product().retailprice != 0) {
                return 'You Save ' + (((self.product().retailprice - self.product().price) * 100) / self.product().retailprice).toFixed(2) + ' %';
            }
            return 0 + ' %';

        });
        self.addToCart = function (item) {
            if (item == undefined) {
                item = self.product();
            }

            item.productname = self.productName().productname;
            item.productimageurl = self.productName().imageurl;
            debugger;
            AddItemToCart(item);
            UpdateSession();
        }
    }
    ko.applyBindings(productDetailViewModel(), document.getElementById('productdetail'));
});



$(document).ready(function () {
    $('.collapse').on('shown.bs.collapse', function () {
        $(this).parent().find(".glyphicon-plus").removeClass("glyphicon-plus").addClass("glyphicon-minus");
    }).on('hidden.bs.collapse', function () {
        $(this).parent().find(".glyphicon-minus").removeClass("glyphicon-minus").addClass("glyphicon-plus");
    });
});

var data;

function getProductDetail() {
    var request = {};
    request.producturl = url;
    var send = {};
    send.request = request;
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf]8",
        url: "http://api.hgh.com/HGHMobileWebServices.svc/Product_GetByURL",
        data: JSON.stringify(send),
        dataType: "json",
        async: false,
        success: function (msg) {
            console.log(msg);
            var res = JSON.parse(msg);
            if (res.tblsuccess[0].success == 'true') {
                data = res;
            }
            else {
                alert(res.tblresult[0].responsemessage);
                return false;
            }
        },
        error: function () {
        }
    });
    return data;
}