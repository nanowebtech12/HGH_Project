﻿var cartdata;
var cart = {};
cart.shoppingCart = ko.observableArray();

var User = {}


function IsEmail(email) {

    var emailReg = new RegExp(/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i);
    return emailReg.test(email);

}



function AddItemToCart(cartitem) {
    var cartItem = {};
    var index;
    var quentity;
    var items = $.grep(cart.shoppingCart(), function (e, i) { return e.productid == cartitem.productid });
    var index = cart.shoppingCart().indexOf(items[0]);
    if (index >= 0) {
        cart.shoppingCart()[index].Quentity(cart.shoppingCart()[index].Quentity() + 1);
    }
    else {

        cartItem.productname = cartitem.productname;
        cartItem.imageurl = cartitem.productimageurl == undefined ? cartitem.imageurl : cartitem.productimageurl;
        cartItem.monthsupply = cartitem.monthsupply == undefined ? '1 Month.' : cartitem.monthsupply;
        cartItem.price = cartitem.price;
        cartItem.retailprice = cartitem.retailprice;
        cartItem.productid = cartitem.productid;
        cartItem.Quentity = ko.observable(cartitem.Quentity == undefined ? 1 : cartitem.Quentity);
        cartItem.TotalItemPrice = ko.observable(cartItem.price * cartItem.Quentity());

        //if (items.length > 0) {
        //    cartItem.Quentity(items[0].Quentity(items[0].Quentity() + 1));


        //}
        cart.shoppingCart.push(cartItem);
    }
}



function UpdateSession () {
    //$.post("/Product/UpdateSession", { shoppingCart: JSON.stringify(ko.toJSON(cart.shoppingCart())) }, function () { });
   
    $.ajax({
        url: '/Product/UpdateSession',
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify({shoppingCart:ko.toJSON(cart.shoppingCart())}),
        global: false,
        success: function () { },
        error: function () { }
    });
    }


$(document).ready(function () {
    cartdata = getShoppingCart();
    if (cartdata.d) {
        var cartjson = cartdata.data;// JSON.parse(cartdata.data);
        for (var i = 0; i < cartjson.length; i++) {
            AddItemToCart(cartjson[i]);
        }
        // cart.shoppingCart = ko.observableArray(cartjson);
    }

    function cartViewModel() {
        var self = this;
        self.totalItems = ko.computed(function () {
            var total = 0;
            for (var i = 0; i < cart.shoppingCart().length; i++) {
                total += cart.shoppingCart()[i].Quentity;
            }
            return total;
        });
    }

    ko.applyBindings(cartViewModel(), document.getElementById('shopingCartcount'));
    //ko.applyBindings(cartViewModel(), document.getElementById('cartitmes'));
    //self.addToCart = function (products) {
    //    self.shoppingCart.push(products);
    //    $.post("/Product/UpdateSession", { shoppingCart: JSON.stringify(ko.toJSON(self.shoppingCart())) }, function () { });
    //}
});

function getShoppingCart() {
    var cdata;
    $.ajax({
        url: '/product/GetShoppingCart',
        type: 'POST',
        async: false,
        global: false,
        success: function (cartdata) {
            cdata = cartdata;
        },
    });
    return cdata;
    //            return $.post('/product/GetShoppingCart', function (cartdata) { $('#cartdatda').val(cartdata.d); });
}
/*Show loader */
$(document).ajaxStart(
function () {
    $('#loader').css('display', 'block');
    $('#wraper').css('opacity', '0.3');
    $('#loader').css('z-index', '10000000');
});
/*Hide loader*/
$(document).ajaxStop(
function () {
    $('#loader').css('display', 'none');
    $('#wraper').css('opacity', '1')
    $('#loader').css('z-index', '10000000');
});
/*for shoping cart fly function*/
$('body').on('click', '.crtbtnd', function () {
    var imgtodrag = $('#pimage');
    animateImage(imgtodrag);
});

$('body').on('click', '.crtbtn', function () {
    var imgtodrag = $(this).parent().find('img');

    animateImage(imgtodrag);
});
function animateImage(imgtodrag) {
    var cart = $('#shopingCart');
    if (imgtodrag) {
        var imgclone = imgtodrag.clone()
            .offset({
                top: imgtodrag.offset().top,
                left: imgtodrag.offset().left
            })
            .css({
                'opacity': '0.5',
                'position': 'absolute',
                'height': '150px',
                'width': '150px',
                'z-index': '100'
            })
            .appendTo($('body'))
            .animate({
                'top': cart.offset().top + 10,
                'left': cart.offset().left + 10,
                'width': 50,
                'height': 50
            }, 1000, 'easeInOutExpo');

        setTimeout(function () {
            cart.effect("shake", {
                times: 2,
                distance: 10
            }, 200);
        }, 1500);

        imgclone.animate({
            'width': 0,
            'height': 0
        }, function () {
            $(this).detach()
        });
    }
}
/*end of the image fly  functionality*/