﻿
var alldata = GetSearchResult();
function SearchResultViewModel() {
    var self = this;
    self.Products = alldata.tblproducts;
    self.Pages = alldata.tblpages;
}
$(function () { ko.applyBindings(new SearchResultViewModel(), document.getElementById('products')); });

function GetSearchResult() {
    var request = {};
    request.keyword = srchtext;
    var send = {};
    send.request = request;
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf]8",
        url: "http://api.hgh.com/HGHMobileWebServices.svc/Product_GetByKeyword",
        data: JSON.stringify(send),
        dataType: "json",
        async: false,
        success: function (msg) {
            result = JSON.parse(msg);
        },
        error: function () {
            alert('Error while process your request.');
           
            //window.location=window.location.
        }
    });
    if (result["tblsuccess"][0].success == 'true') {
        return result;

    }
    else {
        alert(result["tblsuccess"][0].errormessage);
        hideLoader();
        return;
    }
}
