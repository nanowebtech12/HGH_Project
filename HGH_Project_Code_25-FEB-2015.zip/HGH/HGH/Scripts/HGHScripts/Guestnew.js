
﻿$(document).ready(function () {
    if ($("#bill_chk1").prop("checked") == true) {
        $("#add_2").slideDown();
    }

    $("#checkInfo").hide();

    $("#donation").prop('disabled', true);

    $("#stateText").hide();


});


﻿$(document).ready(function () {
    $('#stateText').hide();
    $('#stateText2').hide();
});

$('#bill_chk1').click(function () {
    debugger;
    if ($("#bill_chk1").prop("checked") == true) {
        $("#add_2").slideDown();
    }
    else {
        $("#add_2").slideUp();
    }
});

$("#Country").change(function () {
    var country = $("#Country").val();
    if (country != "United States of America") {
        $("#stateText").show();
        $("#state").hide();
    }
    else {
        $("#stateText").hide();
        $("#state").show();
    }

});

$("#countryName").change(function () {
    var country = $("#countryName").val();
    if (country != "United States of America") {
        $("#stateText2").show();
        $("#state2").hide();
    }
    else {
        $("#stateText2").hide();
        $("#state2").show();
    }

});



function Payment() {
    if ($("#form1").valid() == true) {
        $('#billing').css('display', 'none')
        $("#payment").show();

        $("#paymentMethod").change(function () {

            var details = $("#paymentMethod").val();
            if (details == "E-Check") {
                $("#creditcard").hide();
                $("#checkInfo").show();
            }
            else {
                $("#creditcard").show();
                $("#checkInfo").hide();
            }
        });
    }
}

function country() {

    $("#Country").change(function () {
        var country = $("#Country").val();
        if (country != "United States of America") {
            $("#stateText").show();
            $("#state").hide();
        }
        else {
            $("#stateText").hide();
            $("#state").show();
        }

    });
}


$("#stateText1").hide();
function Country2() {
    $("#countryName").change(function () {
        var country = $("#countryName").val();
        if (country != "United States of America") {
            $("#stateText1").show();
            $("#state2").hide();
        }
        else {
            $("#stateText1").hide();
            $("#state2").show();
        }

    });
}

$("#form1").validate({
    rules: {
        username: {
            required: true,
            
        },
        lastname: {
            required: true,
            
        },
        email: {
            required: true,
            checkemail: true
        },
        phone: {
            required: true,
            
          },
        state: {
            required: true
        },
        stateText: {
            required:true,
           
        },
        line1: {
            required: true,
            
        },
        line2: {
            required: true,
           
        },
        city: {
            required: true,
           
        },
        zipcode: {
            required: true,
           
        },
        firstname2: {
            required: true,
            
        },
        lastname2: {
            required: true,
            
        },
        
        line12: {
            required: true,
            
        },
        line22: {
            required: true,
            
        },
        city2: {
            required:true
        },
        state2: {
            required:true
        },
        zipcode2: {
            required: true,
           
            
        }
    },
    messages: {
        username: {
            required: "Please enter username",
            
        },
        lastname: {
            required: "Please enter lastname",
            
        },
        email: {
            required: "Please enter your email",
            email: "Please enter a valid email"
        },
        phone: {
            required: "Please enter mobile numbers",
          },
       
        state: {
            required: "Please select state",
        },
        stateText: {
            required: "Please Enter State",
            
        },
        line1: {
            required: "Please enter line1",
            
        },
        line2: {
            required: "Please enter line2",
            
        },
        city: {
            required: "Please enter city",
            
        },
        zipcode: {
            required: "Please enter zipcode",
            
        },
        firstname2: {
            required: "Please enter Shipping First Name",
            
        },
        lastname2: {
            required: "Please enter Shipping Last Name",
           
        },
        line12: {
            required: "Please enter street address to ship",
            
        },
        line22: {
            required: "Please enter strret address to shipment",
            
        },
        city2: {
            required: "Please enter City"
        },
        state2: {
            required: "Please select Shipping State"
        },
        zipcode2: {
            required: "Please enter Shipping ZipCode",
            
        }
    }
});

jQuery.validator.addMethod("checkemail", function (value, element) {
    return this.optional(element) || /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/.test(value) || /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/.test(value);
}, "Please enter your correct email");

//jQuery.validator.addMethod("phoneUs", function (value, element) {
//    return this.optional(element) || (/^(\+?1-?)?(\([2-9]\d{2}\)|[2-9]\d{2})-?[2-9]\d{2}-?\d{4}$/);
//}, "Please specify a valid phone number");

function donate() {
    if ($("#donateChk").is(":checked", true)) {
        $("#donation").prop('disabled', false);
    }
    else {
        $("#donation").prop('disabled', true);
    }

}

function checkout() {
    if ($("#form2").valid() == true) {
        alert('Success');
    }
}

$("#form2").validate({
    rules: {
        paymenttype: {
            required: true,
        },
        cardinfo: {
            required: true,
            creditcard: true
        },
        security: {
            required: true,
            rangelength: [3, 4],
            number: true
        },
        bankname: {
            required: true
        },
        bankcity: {
            required: true
        },
        checkaccount: {
            required: true
        },
        bankrouting: {
            required: true
        },
        check: {
            required: true
        }
    },
    messages: {
        paymenttype: {
            required: "Please select payment type",
        },
        cardinfo: {
            required: "Please enter credit card no",
            creditcard: "Please enter a valid number"
        },
        security: {
            required: "Please enter security number",
            rangelength: "Please enter a valid number",
            number: "Please enter a only number"
        },
        bankname: {
            required: "Please enter bank name"
        },
        bankcity: {
            required: "Please enter bank city"
        },
        checkaccount: {
            required: "Please enter check account"
        },
        bankrouting: {
            required: "Please enter bank routing"
        },
        check: {
            required: "Please enter check"
        }
    }
});



function Back() {
    $('#billing').show();
    $("#payment").css('display', 'none');
}



