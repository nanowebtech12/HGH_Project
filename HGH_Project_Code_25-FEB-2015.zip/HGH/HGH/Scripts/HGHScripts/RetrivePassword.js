﻿$(document).ready(function () {
    DrawCaptcha();
});

var result;

function DrawCaptcha() {
    var a = Math.ceil(Math.random() * 10) + '';
    var b = Math.ceil(Math.random() * 10) + '';
    var c = Math.ceil(Math.random() * 10) + '';
    var d = Math.ceil(Math.random() * 10) + '';
    var e = Math.ceil(Math.random() * 10) + '';
    var f = Math.ceil(Math.random() * 10) + '';
    var g = Math.ceil(Math.random() * 10) + '';
    var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' ' + f + ' ' + g;
    document.getElementById("txtCaptcha").value = code;
    $('#txtcode').val('');
}

function clearfields() {
    $('#email').val('');
    $('#txtcode').val('');
    DrawCaptcha();
}


function ValidateAndSendRequest() {
    $('.errormsg').text('');
    var email = $('#email').val().trim();
    var code = $('#txtcode').val().trim();
    var ccode = $('#txtCaptcha').val().trim().replace(/ /g, '');

    if (email == '') {
        $('.errormsg').text('Please enter email address.');
        clearfields();
        return false;
    }
    if (!IsEmail(email)) {
        $('.errormsg').text('Please enter a valid  email address.');
        clearfields();
        return false;
    }

    if (code == '') {
        $('.errormsg').text('Please enter code.');
        clearfields();
        return false;
    }

    if (code != ccode) {
        $('.errormsg').text('Please enter valid code.');
        clearfields();
        return false;
    }

    var result = RetrivePassword(email);
    var jsonresult = JSON.parse(result);
    debugger;
    if(jsonresult.tblresult[0].responsecode==0)
    {
        $('.errormsg').text(jsonresult.tblresult[0].responsemessage);
        clearfields();
        return false;
    }
    if (jsonresult.tblresult[0].responsecode == 1) {
        $('.errormsg').css('color', 'green');
        $('.errormsg').text(jsonresult.tblresult[0].responsemessage);
        clearfields();
    }
}



function RetrivePassword(email) {
    var request = {};
    request.email = email;
    var send = {};
    send.request = request;
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf]8",
        url: "http://api.hgh.com/HGHMobileWebServices.svc/MyAccount_RetrievePassword",
        data: JSON.stringify(send), dataType: "json", async: false, success: function (msg) {
            result = msg;
        }, error: function () {
            alert('Error while processing your request');
        }
    });
    return result;
}