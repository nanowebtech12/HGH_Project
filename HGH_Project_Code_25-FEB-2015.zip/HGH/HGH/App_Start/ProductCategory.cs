﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Routing;

namespace HGH.App_Start
{
    class ProductCategory:IRouteConstraint
    {

        public bool Match(System.Web.HttpContextBase httpContext, Route route, string parameterName, RouteValueDictionary values, RouteDirection routeDirection)
        {
            var cat = values["action"].ToString();
            if (cat.ToLower().EndsWith(".aspx"))
            {
                values["controller"] = "Product";
                values["Action"] = "ProductDetail";
                values["cat"] = cat;
            }
            return true;

        }
    }
}
