﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HGH.Models
{
    public class Cart
    {
        public long productid { get; set; }
        public string productname { get; set; }
        public string imageurl { get; set; }
        public string monthsupply { get; set; }
        public float price { get; set; }
        public float retailprice { get; set; }
        public int Quentity { get; set; }
    }
}